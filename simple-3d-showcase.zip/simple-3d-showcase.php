<?php
/**
 * Plugin Name: Simple 3D Showcase
 * Plugin URI: http://localhost:10016/
 * Description: Simple 3D model showcase viewer for WordPress using model-viewer. Great for exhibitions, kiosks, and product presentation.
 * Version: 1.0.0
 * Author: Davtyan Alik
 * License: GPL2+
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class Simple_3D_Showcase_Plugin {
	public function __construct() {
		add_shortcode( 'simple_3d_showcase', array( $this, 'render_shortcode' ) );
		add_action( 'wp_head', array( $this, 'print_model_viewer_script' ) );
		add_filter( 'upload_mimes', array( $this, 'allow_3d_uploads' ) );
	}

	public function allow_3d_uploads( $mimes ) {
		$mimes['glb']  = 'model/gltf-binary';
		$mimes['gltf'] = 'model/gltf+json';
		return $mimes;
	}

	public function print_model_viewer_script() {
		?>
		<script type="module" src="https://unpkg.com/@google/model-viewer/dist/model-viewer.min.js"></script>
		<?php
	}

	public function render_shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'model_url'       => '',
				'height'          => '600px',
				'auto_rotate'     => 'true',
				'camera_controls' => 'true',
				'background'      => '#dbdbdb',
			),
			$atts,
			'simple_3d_showcase'
		);

		if ( empty( $atts['model_url'] ) ) {
			return '<div style="padding:16px;border:1px solid #ddd;">No model_url provided.</div>';
		}

		$id = 'simple-3d-showcase-' . wp_rand( 1000, 999999 );

		$auto_rotate     = filter_var( $atts['auto_rotate'], FILTER_VALIDATE_BOOLEAN );
		$camera_controls = filter_var( $atts['camera_controls'], FILTER_VALIDATE_BOOLEAN );

		ob_start();
		?>
		<div id="<?php echo esc_attr( $id ); ?>" class="simple-3d-showcase-wrap">
			<style>
				#<?php echo esc_attr( $id ); ?> {
					position: relative;
					width: 100%;
					background: <?php echo esc_attr( $atts['background'] ); ?>;
					border-radius: 16px;
					overflow: hidden;
				}
				#<?php echo esc_attr( $id ); ?> model-viewer {
					display: block;
					width: 100%;
					height: <?php echo esc_attr( $atts['height'] ); ?>;
					background: <?php echo esc_attr( $atts['background'] ); ?>;
				}
				#<?php echo esc_attr( $id ); ?> .s3d-controls {
					position: absolute;
					right: 16px;
					bottom: 16px;
					display: flex;
					gap: 8px;
					z-index: 10;
				}
				#<?php echo esc_attr( $id ); ?> .s3d-btn {
					border: 0;
					border-radius: 999px;
					padding: 10px 14px;
					cursor: pointer;
					background: rgba(0,0,0,.82);
					color: #fff;
					font-size: 13px;
				}
				#<?php echo esc_attr( $id ); ?> .s3d-hint {
					position: absolute;
					left: 16px;
					bottom: 16px;
					z-index: 10;
					padding: 8px 12px;
					border-radius: 999px;
					background: rgba(219, 219, 219, 0.92);
					font-size: 12px;
				}
			</style>

			<model-viewer
				id="<?php echo esc_attr( $id ); ?>-viewer"
				src="<?php echo esc_url( $atts['model_url'] ); ?>"
				alt="3D model"
				loading="eager"
				reveal="auto"
				environment-image="neutral"
				interaction-prompt="none"
				touch-action="pan-y"
				camera-orbit="45deg 75deg auto"
				field-of-view="30deg"
				shadow-intensity="1"
				exposure="1"
				<?php echo $auto_rotate ? 'auto-rotate' : ''; ?>
				<?php echo $camera_controls ? 'camera-controls' : ''; ?>
			></model-viewer>

			<div class="s3d-hint">Drag to rotate</div>

			<div class="s3d-controls">
				<button type="button" class="s3d-btn js-reset">Reset</button>
				<button type="button" class="s3d-btn js-rotate"><?php echo $auto_rotate ? 'Pause' : 'Rotate'; ?></button>
				<button type="button" class="s3d-btn js-fullscreen">Fullscreen</button>
			</div>
		</div>

		<script>
		document.addEventListener('DOMContentLoaded', function () {
			const wrap = document.getElementById('<?php echo esc_js( $id ); ?>');
			if (!wrap) return;

			const viewer = document.getElementById('<?php echo esc_js( $id ); ?>-viewer');
			const resetBtn = wrap.querySelector('.js-reset');
			const rotateBtn = wrap.querySelector('.js-rotate');
			const fsBtn = wrap.querySelector('.js-fullscreen');

			let rotating = <?php echo $auto_rotate ? 'true' : 'false'; ?>;

			resetBtn.addEventListener('click', function () {
				viewer.cameraOrbit = '45deg 75deg auto';
				if (viewer.jumpCameraToGoal) viewer.jumpCameraToGoal();
			});

			rotateBtn.addEventListener('click', function () {
				rotating = !rotating;
				if (rotating) {
					viewer.setAttribute('auto-rotate', '');
					rotateBtn.textContent = 'Pause';
				} else {
					viewer.removeAttribute('auto-rotate');
					rotateBtn.textContent = 'Rotate';
				}
			});

			fsBtn.addEventListener('click', function () {
				if (!document.fullscreenElement) {
					if (wrap.requestFullscreen) wrap.requestFullscreen();
				} else {
					if (document.exitFullscreen) document.exitFullscreen();
				}
			});
		});
		</script>
		<?php

		return ob_get_clean();
	}
}

new Simple_3D_Showcase_Plugin();